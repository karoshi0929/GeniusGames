﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CommonLibrary;

namespace Baseball_Player
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        ClientFunction m_Client = null;
        private string m_ClientID = string.Empty;

        public MainWindow()
        {
            InitializeComponent();

            this.UserControl_LoginScreen.Button_LoginEvent += UserControl_LoginScreen_Button_LoginEvent;
        }

        private void UserControl_LoginScreen_Button_LoginEvent(string text)
        {
            m_Client = new ClientFunction("192.168.2.42", 10000, text);

            if (m_Client.ConnectServer())
            {
                UserControl_LoginScreen.Visibility = Visibility.Collapsed;
                UserControl_PlayingScreen.Visibility = Visibility.Visible;

                LoginPacket loginPacket = new LoginPacket();
                loginPacket.clientID = text;
                loginPacket.IsCheckDuplication = false;

                m_Client.SendMessage(CommonLibrary.Header.Login, loginPacket, m_Client.ao.WorkingSocket);
            }
        }
    }
}
