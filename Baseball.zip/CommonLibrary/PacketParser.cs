﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Runtime.InteropServices;

namespace CommonLibrary
{
    public class PacketParser
    {
        public static byte[] RawSerialize(object anything)
        {
            string strError;
            try
            {
                int rawsize = Marshal.SizeOf(anything);

                IntPtr buffer = Marshal.AllocHGlobal(rawsize);

                Marshal.StructureToPtr(anything, buffer, false);

                byte[] rawdatas = new byte[rawsize];

                Marshal.Copy(buffer, rawdatas, 0, rawsize);

                Marshal.FreeHGlobal(buffer);
                return rawdatas;

            }
            catch (Exception _ex)
            {
                strError = _ex.Message;
                return null;
            }
        }

        public static void PacketParsing(byte[] packet, Socket clientSocket = null)
        {
            switch (packet[0])
            {
                case (byte)Header.Login:
                    LoginPacket loginPacket = LoginPacket_ToStruct(packet);
                    EventManager.Instance.ReceiveLoginPacket(loginPacket, clientSocket);
                    break;
                //case (byte)Header.Game:
                //    HandleGamePacket handleGamePacket = HandleGamePacket_ToStruct(packet);
                //    EventManager.Instance.ReceiveHandleGamePacket(handleGamePacket);
                //    break;
                //case (byte)Header.GameMotion:
                //    IndianPokerGamePacket indianpokerGamePacket = IndianPokerGamePacket_ToStruct(packet);
                //    EventManager.Instance.ReceiveIndianPokerGamePacket(indianpokerGamePacket);
                //    break;
            }
        }
        public static LoginPacket LoginPacket_ToStruct(byte[] packet)
        {
            LoginPacket temp = new LoginPacket();
            object obj = (object)temp;
            PacketToStruct(packet, ref obj);
            temp = (LoginPacket)obj;
            return temp;
        }

        public static HandleGamePacket HandleGamePacket_ToStruct(byte[] packet)
        {
            HandleGamePacket temp = new HandleGamePacket();
            object obj = (object)temp;
            PacketToStruct(packet, ref obj);
            temp = (HandleGamePacket)obj;
            return temp;
        }

        public static void PacketToStruct(byte[] packet, ref object topicstruct)
        {
            int len = Marshal.SizeOf(topicstruct);
            IntPtr ptr = Marshal.AllocHGlobal(len);
            Marshal.Copy(packet, 1, ptr, len);
            topicstruct = Marshal.PtrToStructure(ptr, topicstruct.GetType());
            Marshal.FreeHGlobal(ptr);
        }
    }
}
