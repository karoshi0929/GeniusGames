﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;

namespace CommonLibrary
{
    public class EventManager
    {
        private static readonly EventManager instance = new EventManager();
        
        public static EventManager Instance
        {
            get { return instance; }
        }

        /* ************************************************************************************ */
        public class LoginPacketReceivedArgs : EventArgs
        {
            public LoginPacket Data
            { get; set; }
            public Socket ClientSocket
            { get; set; }
        }

        public delegate void LoginPacketEventHandler(LoginPacketReceivedArgs e);
        public event LoginPacketEventHandler LoginPacketEvent;

        public void ReceiveLoginPacket(LoginPacket loginPacket, Socket clientSocket)
        {
            LoginPacketReceivedArgs parameter = new LoginPacketReceivedArgs();
            parameter.Data = loginPacket;
            parameter.ClientSocket = clientSocket;


            LoginPacketEvent(parameter);
        }
        /* ************************************************************************************ */
    }
}
