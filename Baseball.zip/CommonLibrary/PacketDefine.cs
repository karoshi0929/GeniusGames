﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Runtime.InteropServices;

namespace CommonLibrary
{
    public enum Header
    {
        Login
    }

    public struct LoginPacket
    {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 13)]
        public string clientID;

        /// <summary>
        /// 로그인 여부
        /// </summary>
        public bool isLogin;

        /// <summary>
        /// 유저 아이디 중복 검사
        /// </summary>
        public bool IsCheckDuplication;
    }

    public struct HandleGamePacket
    {

    }

    public class PacketDefine
    {
        public static byte[] MakePacket(Header header, object Data)
        {
            byte[] temp = new byte[] { };
            temp = PacketParser.RawSerialize(Data);
            byte[] outpacket = new byte[temp.Length + 1];
            outpacket[0] = (byte)header;
            Array.Copy(temp, 0, outpacket, 1, temp.Length);

            //packet 검사 코드
            //outpakcet[outpacket.Length - 1] = Crc8.ComputeChecksum(outpacket);

            return outpacket;
        }
    }
}
